package com.example.portonesinteligentes;

data class User(val username: String, val password: String)